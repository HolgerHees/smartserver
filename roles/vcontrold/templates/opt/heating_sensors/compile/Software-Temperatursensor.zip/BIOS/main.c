//*----------------------------------------------------------------------------
// main.c
//*----------------------------------------------------------------------------
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util/delay.h>
#include "usb_rawhid.h"
#include "onewire.h"
#include "ds18x20.h"
//*----------------------------------------------------------------------------
#define CPU_PRESCALE(n)	(CLKPR = 0x80, CLKPR = (n))
#define MAXSENSORS 5
//*----------------------------------------------------------------------------
volatile uint8_t do_output = 0;
uint8_t  buffer[64];
uint8_t  nSensors;
uint8_t  gSensorIDs[MAXSENSORS][OW_ROMCODE_SIZE];
//*----------------------------------------------------------------------------
uint8_t Search_Sensors(void)
{
  uint8_t i, id[OW_ROMCODE_SIZE], diff, anz = 0; 
  
  ow_reset();
  diff = OW_SEARCH_FIRST;
  while(diff != OW_LAST_DEVICE && anz < MAXSENSORS) {
    DS18X20_find_sensor(&diff, &id[0]);
    if(diff == OW_PRESENCE_ERR) { break; }
    if(diff == OW_DATA_ERR) { break; }
    for(i = 0; i < OW_ROMCODE_SIZE; i++) {
      gSensorIDs[anz][i] = id[i];
    }
    if(id[0] == DS18B20_FAMILY_CODE) { anz++; }
  }
  return anz; 
}  
//*----------------------------------------------------------------------------
int main(void)
{
	int8_t r;
	uint8_t i, sensor = 0;

	// set for 16 MHz clock
	CPU_PRESCALE(0);

	// Initialize the USB, and then wait for the host to set configuration.
	// If the Teensy is powered without a PC connected to the USB port,
	// this will wait forever.
	usb_init();
	while (!usb_configured()) /* wait */ ;

	// Wait an extra second for the PC's operating system to load drivers
	// and do whatever it does to actually be ready for input
	_delay_ms(1000);

  DDRC  = 0xC0;    // LED1, LED2
  PORTC = 0xC0; 

#ifndef OW_ONE_BUS
  ow_set_bus(&PINB, &PORTB, &DDRB, PB6);
#endif
  nSensors = Search_Sensors(); 

  // Configure timer 0 to generate a timer overflow interrupt every
  // 256*1024 clock cycles, or approx 61 Hz when using 16 MHz clock
  TCCR0A = 0x00;
  TCCR0B = 0x05;
  TIMSK0 = (1 << TOIE0);

	while(1) {
	  //................................................................
		// if received data, do something with it
		r = usb_rawhid_recv(buffer, 0);
		if (r > 0) {
			// output 4 bits to D0, D1, D2, D3 pins
			DDRD = 0x0F;
			PORTD = (PORTD & 0xF0) | (buffer[0] & 0x0F);
		}
	  //................................................................
		// if time to send output, transmit something interesting
		if(do_output) {
			do_output = 0;
			PORTC &= ~0x80;    // LEDR ON
      for(i = 0; i < 64; i++) { buffer[i] = 0; }
		  if(nSensors) {
        buffer[0] = nSensors;
        buffer[1] = sensor + 1;
        buffer[2] = DS18X20_get_power_status(&gSensorIDs[sensor][0]);
        for(i = 0; i < OW_ROMCODE_SIZE; i++) {
          buffer[0x08 + i] = gSensorIDs[sensor][i];
        }  
		    if(DS18X20_start_meas(buffer[2], &gSensorIDs[sensor][0]) == DS18X20_OK) {
  				_delay_ms(DS18B20_TCONV_12BIT);
  			  DS18X20_read_decicelsius(&gSensorIDs[sensor][0], (int16_t *)&buffer[4]);
        }
        sensor++;
        if(sensor >= nSensors) { sensor = 0; }		    
		  }
			usb_rawhid_send(buffer, 50);
			PORTC |= 0x80;    // LEDR OFF
    }
	  //................................................................
	}
}
//*----------------------------------------------------------------------------
// This interrupt routine is run approx 61 times per second.
//*----------------------------------------------------------------------------
ISR(TIMER0_OVF_vect)
{
	static uint8_t count=0;

	// set the do_output variable every 2 seconds
	if (++count > 61) {
		count = 0;
		do_output = 1;
	}
}
//*----------------------------------------------------------------------------

