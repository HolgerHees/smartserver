CACHE MANIFEST

# <?php echo $_['version']; ?>
# Nonce: <?php p(\OC::$server->getContentSecurityPolicyNonceManager()->getNonce()); ?>

CACHE:
<?php echo $_['keeweb']; ?>


NETWORK:
*
